
import { z } from 'zod';
import { insertStockItemSchema, insertSellerSchema, insertSaleSchema, stockItems, sellers, sales } from './schema';

export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  internal: z.object({
    message: z.string(),
  }),
};

export const api = {
  stock: {
    list: {
      method: 'GET' as const,
      path: '/api/stock',
      responses: {
        200: z.array(z.custom<typeof stockItems.$inferSelect>()),
      },
    },
    update: {
      method: 'PUT' as const,
      path: '/api/stock/:id',
      input: insertStockItemSchema.partial(),
      responses: {
        200: z.custom<typeof stockItems.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    },
    // Initialize stock helper (if needed, or just seeded)
    reset: {
      method: 'POST' as const,
      path: '/api/stock/reset',
      responses: {
        200: z.object({ message: z.string() }),
      },
    }
  },
  sellers: {
    list: {
      method: 'GET' as const,
      path: '/api/sellers',
      responses: {
        200: z.array(z.custom<typeof sellers.$inferSelect>()),
      },
    },
    update: {
      method: 'PUT' as const,
      path: '/api/sellers/:id',
      input: insertSellerSchema.partial(),
      responses: {
        200: z.custom<typeof sellers.$inferSelect>(),
        404: errorSchemas.notFound,
      },
    }
  },
  sales: {
    list: {
      method: 'GET' as const,
      path: '/api/sales',
      responses: {
        200: z.array(z.custom<typeof sales.$inferSelect>()),
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/sales',
      input: insertSaleSchema,
      responses: {
        201: z.custom<typeof sales.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
  }
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}
