
import { pgTable, text, serial, integer, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Stock items (track inventory by color and size)
export const stockItems = pgTable("stock_items", {
  id: serial("id").primaryKey(),
  color: text("color").notNull(), // 'Gris' or 'Noir'
  size: text("size").notNull(),   // 'S', 'M', 'L', 'XL'
  ensembleCount: integer("ensemble_count").default(0).notNull(),
  jacketCount: integer("jacket_count").default(0).notNull(),
  trouserCount: integer("trouser_count").default(0).notNull(),
});

// Sellers (Rafik and Imed)
export const sellers = pgTable("sellers", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  maxEnsembles: integer("max_ensembles").default(0).notNull(), // The "quota" that decreases
});

// Sales history
export const sales = pgTable("sales", {
  id: serial("id").primaryKey(),
  sellerName: text("seller_name").notNull(),
  color: text("color").notNull(),
  size: text("size").notNull(),
  price: integer("price").notNull(),
  itemType: text("item_type").notNull().default("ensemble"), // 'ensemble', 'jacket', 'trouser'
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Schemas for API
export const insertStockItemSchema = createInsertSchema(stockItems).omit({ id: true });
export const insertSellerSchema = createInsertSchema(sellers).omit({ id: true });
export const insertSaleSchema = createInsertSchema(sales).omit({ id: true, createdAt: true }).extend({
  itemType: z.enum(['ensemble', 'jacket', 'trouser']).default('ensemble'),
});

// Types
export type StockItem = typeof stockItems.$inferSelect;
export type InsertStockItem = z.infer<typeof insertStockItemSchema>;

export type Seller = typeof sellers.$inferSelect;
export type InsertSeller = z.infer<typeof insertSellerSchema>;

export type Sale = typeof sales.$inferSelect;
export type InsertSale = z.infer<typeof insertSaleSchema>;
