## Packages
date-fns | Date formatting for sales history
framer-motion | Smooth transitions between tabs and list items
lucide-react | Icons for the interface (already in base but good to list)

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  display: ["var(--font-display)"],
  body: ["var(--font-body)"],
}
