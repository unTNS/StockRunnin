import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import { type StockItem } from "@shared/schema";

export function useStock() {
  return useQuery({
    queryKey: [api.stock.list.path],
    queryFn: async () => {
      const res = await fetch(api.stock.list.path);
      if (!res.ok) throw new Error("Failed to fetch stock");
      return api.stock.list.responses[200].parse(await res.json());
    },
  });
}

export function useUpdateStock() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({ id, updates }: { id: number, updates: Partial<StockItem> }) => {
      const url = buildUrl(api.stock.update.path, { id });
      const validated = api.stock.update.input.parse(updates);
      
      const res = await fetch(url, {
        method: api.stock.update.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validated),
      });

      if (!res.ok) {
         if (res.status === 404) throw new Error("Stock item not found");
         throw new Error("Failed to update stock");
      }
      return api.stock.update.responses[200].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.stock.list.path] });
    },
  });
}
