import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import { type InsertSale, type InsertSeller } from "@shared/schema";

// === SELLERS HOOKS ===
export function useSellers() {
  return useQuery({
    queryKey: [api.sellers.list.path],
    queryFn: async () => {
      const res = await fetch(api.sellers.list.path);
      if (!res.ok) throw new Error("Failed to fetch sellers");
      return api.sellers.list.responses[200].parse(await res.json());
    },
  });
}

export function useUpdateSeller() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({ id, updates }: { id: number, updates: Partial<InsertSeller> }) => {
      const url = buildUrl(api.sellers.update.path, { id });
      const validated = api.sellers.update.input.parse(updates);
      
      const res = await fetch(url, {
        method: api.sellers.update.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validated),
      });

      if (!res.ok) throw new Error("Failed to update seller");
      return api.sellers.update.responses[200].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.sellers.list.path] });
    },
  });
}

// === SALES HOOKS ===
export function useSales() {
  return useQuery({
    queryKey: [api.sales.list.path],
    queryFn: async () => {
      const res = await fetch(api.sales.list.path);
      if (!res.ok) throw new Error("Failed to fetch sales history");
      return api.sales.list.responses[200].parse(await res.json());
    },
  });
}

export function useCreateSale() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (sale: InsertSale) => {
      const validated = api.sales.create.input.parse(sale);
      const res = await fetch(api.sales.create.path, {
        method: api.sales.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validated),
      });

      if (!res.ok) {
        if (res.status === 400) {
          const error = api.sales.create.responses[400].parse(await res.json());
          throw new Error(error.message);
        }
        throw new Error("Failed to create sale");
      }
      return api.sales.create.responses[201].parse(await res.json());
    },
    onSuccess: () => {
      // Invalidate everything affected by a sale
      queryClient.invalidateQueries({ queryKey: [api.sales.list.path] });
      queryClient.invalidateQueries({ queryKey: [api.sellers.list.path] });
      queryClient.invalidateQueries({ queryKey: [api.stock.list.path] });
    },
  });
}
