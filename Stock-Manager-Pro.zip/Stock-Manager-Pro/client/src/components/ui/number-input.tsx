import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Minus, Plus } from "lucide-react";

interface NumberInputProps {
  value: number;
  onChange: (value: number) => void;
  min?: number;
  max?: number;
  disabled?: boolean;
}

export function NumberInput({ value, onChange, min = 0, max = 9999, disabled }: NumberInputProps) {
  const handleDecrement = () => {
    if (value > min) onChange(value - 1);
  };

  const handleIncrement = () => {
    if (value < max) onChange(value + 1);
  };

  return (
    <div className="flex items-center space-x-1">
      <Button 
        variant="outline" 
        size="icon" 
        className="h-8 w-8 rounded-lg border-dashed"
        onClick={handleDecrement}
        disabled={disabled || value <= min}
      >
        <Minus className="h-3 w-3" />
      </Button>
      <div className="w-12 text-center font-mono font-medium">
        {value}
      </div>
      <Button 
        variant="outline" 
        size="icon" 
        className="h-8 w-8 rounded-lg border-dashed"
        onClick={handleIncrement}
        disabled={disabled || value >= max}
      >
        <Plus className="h-3 w-3" />
      </Button>
    </div>
  );
}
