import { useState } from "react";
import { useSellers, useUpdateSeller, useSales, useCreateSale } from "@/hooks/use-sales";
import { useStock } from "@/hooks/use-stock";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { User, Plus, TrendingUp, DollarSign, History, AlertCircle } from "lucide-react";
import { format } from "date-fns";
import { z } from "zod";
import { useToast } from "@/hooks/use-toast";
import { api } from "@shared/routes";

export default function SalesView() {
  const { data: sellers } = useSellers();
  const { data: salesHistory } = useSales();
  const { mutate: createSale, isPending: isCreating } = useCreateSale();
  const { toast } = useToast();

  const [isSaleModalOpen, setIsSaleModalOpen] = useState(false);
  const [formData, setFormData] = useState({
    sellerName: "",
    color: "",
    size: "",
    price: "",
    itemType: "ensemble" as "ensemble" | "jacket" | "trouser"
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    try {
      createSale({
        sellerName: formData.sellerName,
        color: formData.color,
        size: formData.size,
        price: Number(formData.price),
        itemType: formData.itemType
      }, {
        onSuccess: () => {
          setIsSaleModalOpen(false);
          setFormData({ sellerName: "", color: "", size: "", price: "", itemType: "ensemble" });
          toast({ title: "Vente enregistrée", description: "Stock et quota mis à jour avec succès." });
        },
        onError: (err: any) => {
          toast({ variant: "destructive", title: "Erreur", description: err?.message || "Une erreur est survenue" });
        }
      });
    } catch (err) {
      toast({ variant: "destructive", title: "Erreur de validation", description: "Veuillez vérifier vos entrées." });
    }
  };

  return (
    <div className="space-y-8">
      {/* Sellers Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {sellers?.map((seller) => (
          <SellerCard key={seller.id} seller={seller} />
        ))}
      </div>

      {/* Action Bar */}
      <div className="flex items-center justify-between bg-white p-4 rounded-2xl border border-slate-200 shadow-sm">
        <div>
          <h3 className="font-display font-semibold text-lg text-slate-900">Ajouter une vente</h3>
          <p className="text-sm text-slate-500">Enregistrer une nouvelle transaction de vente</p>
        </div>
        
        <Dialog open={isSaleModalOpen} onOpenChange={setIsSaleModalOpen}>
          <DialogTrigger asChild>
            <Button size="lg" className="rounded-xl shadow-lg shadow-primary/20 bg-primary hover:bg-primary/90">
              <Plus className="w-5 h-5 mr-2" />
              Nouvelle vente
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-md rounded-2xl">
            <DialogHeader>
              <DialogTitle className="font-display text-xl">Enregistrer une vente</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4 py-4">
              <div className="space-y-2">
                <label className="text-sm font-medium">Type de vente</label>
                <div className="flex gap-4">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="radio"
                      value="ensemble"
                      checked={formData.itemType === "ensemble"}
                      onChange={(e) => setFormData(prev => ({ ...prev, itemType: "ensemble" as const }))}
                      className="w-4 h-4"
                    />
                    <span className="text-sm">Ensemble</span>
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="radio"
                      value="jacket"
                      checked={formData.itemType === "jacket"}
                      onChange={(e) => setFormData(prev => ({ ...prev, itemType: "jacket" as const }))}
                      className="w-4 h-4"
                    />
                    <span className="text-sm">Veste seule</span>
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="radio"
                      value="trouser"
                      checked={formData.itemType === "trouser"}
                      onChange={(e) => setFormData(prev => ({ ...prev, itemType: "trouser" as const }))}
                      className="w-4 h-4"
                    />
                    <span className="text-sm">Pantalon seul</span>
                  </label>
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Personne</label>
                <Select 
                  value={formData.sellerName} 
                  onValueChange={(val) => setFormData(prev => ({ ...prev, sellerName: val }))}
                >
                  <SelectTrigger className="rounded-xl">
                    <SelectValue placeholder="Sélectionner une personne" />
                  </SelectTrigger>
                  <SelectContent>
                    {sellers?.map(s => (
                      <SelectItem key={s.id} value={s.name}>{s.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Couleur</label>
                  <Select 
                    value={formData.color} 
                    onValueChange={(val) => setFormData(prev => ({ ...prev, color: val }))}
                  >
                    <SelectTrigger className="rounded-xl">
                      <SelectValue placeholder="Couleur" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Gris">Gris</SelectItem>
                      <SelectItem value="Noir">Noir</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Taille</label>
                  <Select 
                    value={formData.size} 
                    onValueChange={(val) => setFormData(prev => ({ ...prev, size: val }))}
                  >
                    <SelectTrigger className="rounded-xl">
                      <SelectValue placeholder="Taille" />
                    </SelectTrigger>
                    <SelectContent>
                      {['S', 'M', 'L', 'XL'].map(s => (
                        <SelectItem key={s} value={s}>{s}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Prix de vente</label>
                <div className="relative">
                  <DollarSign className="absolute left-3 top-2.5 h-5 w-5 text-slate-400" />
                  <Input 
                    type="number" 
                    placeholder="0.00" 
                    className="pl-10 rounded-xl" 
                    value={formData.price}
                    onChange={(e) => setFormData(prev => ({ ...prev, price: e.target.value }))}
                  />
                </div>
              </div>

              <DialogFooter>
                <Button type="submit" disabled={isCreating} className="w-full rounded-xl h-11">
                  {isCreating ? "Enregistrement..." : "Confirmer la vente"}
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* History Table */}
      <Card className="border shadow-md overflow-hidden rounded-2xl">
        <CardHeader className="bg-slate-50/50 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-blue-100 text-blue-600 rounded-lg">
              <History className="w-5 h-5" />
            </div>
            <div>
              <CardTitle className="font-display">Historique des ventes</CardTitle>
              <CardDescription>Transactions récentes triées par date</CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <div className="max-h-[500px] overflow-auto">
            <Table>
              <TableHeader>
                <TableRow className="hover:bg-transparent">
                  <TableHead>Date</TableHead>
                  <TableHead>Personne</TableHead>
                  <TableHead>Détails</TableHead>
                  <TableHead className="text-right">Prix</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {salesHistory?.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={4} className="h-32 text-center text-muted-foreground">
                      Aucune vente enregistrée pour le moment.
                    </TableCell>
                  </TableRow>
                )}
                {salesHistory?.slice().reverse().map((sale) => (
                  <TableRow key={sale.id} className="hover:bg-slate-50/50">
                    <TableCell className="font-medium font-mono text-xs text-slate-500">
                      {sale.createdAt ? format(new Date(sale.createdAt), "MMM d, HH:mm") : "-"}
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <div className="w-6 h-6 rounded-full bg-slate-100 flex items-center justify-center text-xs font-bold text-slate-600">
                          {sale.sellerName.charAt(0)}
                        </div>
                        <span className="font-medium">{sale.sellerName}</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Badge variant="outline" className="bg-slate-50">
                          {sale.color} • {sale.size}
                        </Badge>
                        <Badge variant="secondary" className="text-xs">
                          {sale.itemType === 'ensemble' ? 'Ensemble' : sale.itemType === 'jacket' ? 'Veste' : 'Pantalon'}
                        </Badge>
                      </div>
                    </TableCell>
                    <TableCell className="text-right font-mono font-medium">
                      ${sale.price}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

function SellerCard({ seller }: { seller: any }) {
  const { mutate: updateSeller } = useUpdateSeller();
  const [isEditOpen, setIsEditOpen] = useState(false);
  const [newQuota, setNewQuota] = useState(seller.maxEnsembles.toString());

  const handleUpdate = () => {
    updateSeller({ id: seller.id, updates: { maxEnsembles: Number(newQuota) } });
    setIsEditOpen(false);
  };

  return (
    <Card className="relative overflow-hidden border-2 border-transparent hover:border-primary/10 transition-colors duration-300 shadow-lg shadow-black/5 group">
      <div className="absolute top-0 right-0 p-4 opacity-0 group-hover:opacity-100 transition-opacity">
        <Dialog open={isEditOpen} onOpenChange={setIsEditOpen}>
          <DialogTrigger asChild>
            <Button variant="ghost" size="sm" className="h-8 w-8 p-0 rounded-full bg-slate-100 hover:bg-slate-200" onClick={() => setNewQuota(seller.maxEnsembles.toString())}>
              <span className="sr-only">Edit</span>
              <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z"/><path d="m15 5 4 4"/></svg>
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-xs rounded-xl">
            <DialogHeader>
              <DialogTitle>Mettre à jour le quota</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-2">
              <div className="space-y-2">
                <label className="text-sm font-medium">Max d'ensembles</label>
                <Input 
                  type="number" 
                  value={newQuota} 
                  onChange={(e) => setNewQuota(e.target.value)}
                  className="rounded-lg"
                />
              </div>
              <Button onClick={handleUpdate} className="w-full rounded-lg">Enregistrer</Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <CardContent className="p-6">
        <div className="flex items-start gap-4">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-slate-100 to-slate-200 flex items-center justify-center shadow-inner">
            <User className="w-8 h-8 text-slate-500" />
          </div>
          <div className="flex-1 space-y-1">
            <h3 className="font-display font-bold text-2xl text-slate-900">{seller.name}</h3>
            <p className="text-sm font-medium text-slate-500 uppercase tracking-wide">Sales Representative</p>
          </div>
        </div>

        <div className="mt-8 grid grid-cols-2 gap-4">
          <div className="p-4 rounded-xl bg-primary/5 border border-primary/10">
            <div className="flex items-center gap-2 text-primary text-sm font-medium mb-1">
              <AlertCircle className="w-4 h-4" />
              Remaining Quota
            </div>
            <div className="text-3xl font-display font-bold text-primary">
              {seller.maxEnsembles}
            </div>
          </div>
          
          <div className="p-4 rounded-xl bg-slate-50 border border-slate-100">
            <div className="flex items-center gap-2 text-slate-500 text-sm font-medium mb-1">
              <TrendingUp className="w-4 h-4" />
              Total Sales
            </div>
            {/* Note: In a real app we would count this from sales history or add a field. 
                For this MVP, I'll calculate it from history client-side for immediate feedback */}
            <SalesCounter sellerName={seller.name} />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

function SalesCounter({ sellerName }: { sellerName: string }) {
  const { data: sales } = useSales();
  const count = sales?.filter(s => s.sellerName === sellerName).length || 0;
  
  return (
    <div className="text-3xl font-display font-bold text-slate-700">
      {count}
    </div>
  );
}
