import { useStock, useUpdateStock } from "@/hooks/use-stock";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { NumberInput } from "@/components/ui/number-input";
import { Layers, Shirt, Scissors } from "lucide-react";
import { motion } from "framer-motion";

export default function StockView() {
  const { data: stockItems, isLoading } = useStock();
  const { mutate: updateStock } = useUpdateStock();

  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {[1, 2].map((i) => (
          <Card key={i} className="h-96">
            <CardHeader><Skeleton className="h-8 w-1/3" /></CardHeader>
            <CardContent><Skeleton className="h-64 w-full" /></CardContent>
          </Card>
        ))}
      </div>
    );
  }

  // Group items by color
  const grisItems = stockItems?.filter(item => item.color === 'Gris') || [];
  const noirItems = stockItems?.filter(item => item.color === 'Noir') || [];

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* GRIS STOCK */}
        <StockColorCard 
          title="Stock Gris" 
          colorClass="bg-slate-100 text-slate-800 border-slate-200"
          items={grisItems}
          onUpdate={updateStock}
        />

        {/* NOIR STOCK */}
        <StockColorCard 
          title="Stock Noir" 
          colorClass="bg-slate-900 text-slate-50 border-slate-800"
          items={noirItems}
          onUpdate={updateStock}
          isDark
        />
      </div>
    </div>
  );
}

function StockColorCard({ title, colorClass, items, onUpdate, isDark = false }: any) {
  // Sort sizes logically: S, M, L, XL
  const sizeOrder = { 'S': 1, 'M': 2, 'L': 3, 'XL': 4 };
  const sortedItems = [...items].sort((a, b) => 
    (sizeOrder[a.size as keyof typeof sizeOrder] || 0) - (sizeOrder[b.size as keyof typeof sizeOrder] || 0)
  );

  return (
    <Card className={`overflow-hidden border-2 shadow-xl ${isDark ? 'shadow-black/20' : 'shadow-slate-200/50'} transition-all duration-300 hover:shadow-2xl`}>
      <div className={`p-6 border-b ${isDark ? 'bg-slate-950 border-slate-800' : 'bg-white border-slate-100'}`}>
        <div className="flex items-center justify-between mb-2">
          <h2 className={`text-2xl font-display font-bold ${isDark ? 'text-white' : 'text-slate-900'}`}>
            {title}
          </h2>
          <Badge variant={isDark ? "secondary" : "default"} className="px-3 py-1 text-sm">
            {items.reduce((acc: number, item: any) => acc + Math.min(item.jacketCount, item.trouserCount), 0)} Ensembles
          </Badge>
        </div>
        <p className={`text-sm ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>
          Gestion des stocks pour toutes les tailles
        </p>
      </div>

      <div className={`divide-y ${isDark ? 'divide-slate-800 bg-slate-900' : 'divide-slate-100 bg-white'}`}>
        {sortedItems.map((item: any) => (
          <motion.div 
            key={item.id}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className={`p-6 transition-colors ${isDark ? 'hover:bg-slate-800/50' : 'hover:bg-slate-50'}`}
          >
            <div className="flex items-center gap-4 mb-4">
              <div className={`
                w-10 h-10 rounded-xl flex items-center justify-center font-display font-bold text-lg
                ${isDark ? 'bg-slate-800 text-white' : 'bg-slate-100 text-slate-900'}
              `}>
                {item.size}
              </div>
              <div className="flex-1">
                <h3 className={`font-semibold ${isDark ? 'text-white' : 'text-slate-900'}`}>Taille {item.size}</h3>
                <p className={`text-xs ${isDark ? 'text-slate-500' : 'text-slate-400'}`}>Ensembles disponibles: {Math.min(item.jacketCount, item.trouserCount)}</p>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <InventoryControl 
                label="Vestes" 
                icon={<Shirt className="w-3 h-3" />}
                value={item.jacketCount} 
                onChange={(val) => onUpdate({ id: item.id, updates: { jacketCount: val } })}
                isDark={isDark}
              />
              <InventoryControl 
                label="Pantalons" 
                icon={<Scissors className="w-3 h-3" />}
                value={item.trouserCount} 
                onChange={(val) => onUpdate({ id: item.id, updates: { trouserCount: val } })}
                isDark={isDark}
              />
            </div>
          </motion.div>
        ))}
      </div>
    </Card>
  );
}

function InventoryControl({ label, icon, value, onChange, isDark }: any) {
  return (
    <div className={`p-3 rounded-xl border ${isDark ? 'bg-slate-950/50 border-slate-800' : 'bg-slate-50/50 border-slate-100'}`}>
      <div className="flex items-center gap-2 mb-2 text-xs font-medium uppercase tracking-wider text-slate-500">
        {icon}
        {label}
      </div>
      <div className="flex justify-between items-center">
        <NumberInput 
          value={value} 
          onChange={onChange}
        />
      </div>
    </div>
  );
}
