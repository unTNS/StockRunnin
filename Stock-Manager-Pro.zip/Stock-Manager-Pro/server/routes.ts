
import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  // --- Seed Data ---
  await storage.initStock();
  await storage.initSellers();

  // --- Stock Routes ---
  app.get(api.stock.list.path, async (_req, res) => {
    const stock = await storage.getAllStock();
    res.json(stock);
  });

  app.put(api.stock.update.path, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updates = api.stock.update.input.parse(req.body);
      const updated = await storage.updateStockItem(id, updates);
      res.json(updated);
    } catch (err) {
      res.status(400).json({ message: "Invalid update" });
    }
  });

  // --- Sellers Routes ---
  app.get(api.sellers.list.path, async (_req, res) => {
    const sellers = await storage.getAllSellers();
    res.json(sellers);
  });

  app.put(api.sellers.update.path, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updates = api.sellers.update.input.parse(req.body);
      const updated = await storage.updateSeller(id, updates);
      res.json(updated);
    } catch (err) {
      res.status(400).json({ message: "Invalid update" });
    }
  });

  // --- Sales Routes ---
  app.get(api.sales.list.path, async (_req, res) => {
    const sales = await storage.getAllSales();
    res.json(sales);
  });

  app.post(api.sales.create.path, async (req, res) => {
    try {
      const input = api.sales.create.input.parse(req.body);
      
      // 1. Vérifier le stock disponible selon le type de vente
      const allStock = await storage.getAllStock();
      const stockItem = allStock.find(s => s.color === input.color && s.size === input.size);
      
      if (!stockItem) {
        return res.status(400).json({ 
          message: `Article non trouvé: ${input.color} taille ${input.size}` 
        });
      }

      if (input.itemType === 'ensemble') {
        // Ensemble: vérifier min(vestes, pantalons)
        const availableEnsembles = Math.min(stockItem.jacketCount, stockItem.trouserCount);
        if (availableEnsembles < 1) {
          return res.status(400).json({ 
            message: `Stock insuffisant pour ${input.color} taille ${input.size}` 
          });
        }
      } else if (input.itemType === 'jacket') {
        // Veste seule
        if (stockItem.jacketCount < 1) {
          return res.status(400).json({ 
            message: `Pas assez de vestes ${input.color} taille ${input.size}` 
          });
        }
      } else if (input.itemType === 'trouser') {
        // Pantalon seul
        if (stockItem.trouserCount < 1) {
          return res.status(400).json({ 
            message: `Pas assez de pantalons ${input.color} taille ${input.size}` 
          });
        }
      }

      // 2. Créer la vente
      const sale = await storage.createSale(input);

      // 3. Diminuer le quota du vendeur SEULEMENT pour les ensembles
      if (input.itemType === 'ensemble') {
        const seller = await storage.getSellerByName(input.sellerName);
        if (seller) {
          await storage.updateSeller(seller.id, {
            maxEnsembles: Math.max(0, seller.maxEnsembles - 1)
          });
        }
      }

      // 4. Mettre à jour le stock
      if (input.itemType === 'ensemble') {
        // Un ensemble = 1 veste + 1 pantalon
        await storage.updateStockItem(stockItem.id, {
          jacketCount: Math.max(0, stockItem.jacketCount - 1),
          trouserCount: Math.max(0, stockItem.trouserCount - 1)
        });
      } else if (input.itemType === 'jacket') {
        // Enlever une veste
        await storage.updateStockItem(stockItem.id, {
          jacketCount: Math.max(0, stockItem.jacketCount - 1)
        });
      } else if (input.itemType === 'trouser') {
        // Enlever un pantalon
        await storage.updateStockItem(stockItem.id, {
          trouserCount: Math.max(0, stockItem.trouserCount - 1)
        });
      }

      res.status(201).json(sale);
    } catch (err) {
      if (err instanceof z.ZodError) {
        res.status(400).json({ message: err.errors[0].message });
      } else {
        res.status(500).json({ message: "Erreur serveur" });
      }
    }
  });

  return httpServer;
}
