
import { db } from "./db";
import {
  stockItems, sellers, sales,
  type StockItem, type InsertStockItem,
  type Seller, type InsertSeller,
  type Sale, type InsertSale
} from "@shared/schema";
import { eq, desc } from "drizzle-orm";

export interface IStorage {
  // Stock
  getAllStock(): Promise<StockItem[]>;
  getStockItem(id: number): Promise<StockItem | undefined>;
  updateStockItem(id: number, updates: Partial<InsertStockItem>): Promise<StockItem>;
  initStock(): Promise<void>; // Seed initial data

  // Sellers
  getAllSellers(): Promise<Seller[]>;
  getSeller(id: number): Promise<Seller | undefined>;
  getSellerByName(name: string): Promise<Seller | undefined>;
  updateSeller(id: number, updates: Partial<InsertSeller>): Promise<Seller>;
  initSellers(): Promise<void>;

  // Sales
  getAllSales(): Promise<Sale[]>;
  createSale(sale: InsertSale): Promise<Sale>;
}

export class DatabaseStorage implements IStorage {
  async getAllStock(): Promise<StockItem[]> {
    return await db.select().from(stockItems).orderBy(stockItems.color, stockItems.size);
  }

  async getStockItem(id: number): Promise<StockItem | undefined> {
    const [item] = await db.select().from(stockItems).where(eq(stockItems.id, id));
    return item;
  }

  async updateStockItem(id: number, updates: Partial<InsertStockItem>): Promise<StockItem> {
    const [updated] = await db.update(stockItems)
      .set(updates)
      .where(eq(stockItems.id, id))
      .returning();
    return updated;
  }

  async initStock(): Promise<void> {
    const colors = ["Gris", "Noir"];
    const sizes = ["S", "M", "L", "XL"];
    
    const existing = await this.getAllStock();
    if (existing.length > 0) return;

    for (const color of colors) {
      for (const size of sizes) {
        await db.insert(stockItems).values({
          color,
          size,
          ensembleCount: 0,
          jacketCount: 0,
          trouserCount: 0
        });
      }
    }
  }

  async getAllSellers(): Promise<Seller[]> {
    return await db.select().from(sellers);
  }

  async getSeller(id: number): Promise<Seller | undefined> {
    const [seller] = await db.select().from(sellers).where(eq(sellers.id, id));
    return seller;
  }

  async getSellerByName(name: string): Promise<Seller | undefined> {
    const [seller] = await db.select().from(sellers).where(eq(sellers.name, name));
    return seller;
  }

  async updateSeller(id: number, updates: Partial<InsertSeller>): Promise<Seller> {
    const [updated] = await db.update(sellers)
      .set(updates)
      .where(eq(sellers.id, id))
      .returning();
    return updated;
  }

  async initSellers(): Promise<void> {
    const existing = await this.getAllSellers();
    if (existing.length > 0) return;

    await db.insert(sellers).values([
      { name: "Rafik", maxEnsembles: 100 },
      { name: "Imed", maxEnsembles: 100 }
    ]);
  }

  async getAllSales(): Promise<Sale[]> {
    return await db.select().from(sales).orderBy(desc(sales.createdAt));
  }

  async createSale(insertSale: InsertSale): Promise<Sale> {
    // Transactional logic could go here, but for simplicity in MVP we'll do it in routes or sequential
    const [sale] = await db.insert(sales).values(insertSale).returning();
    return sale;
  }

  async getAvailableEnsembles(color: string, size: string): Promise<number> {
    const stockItem = (await this.getAllStock()).find(
      s => s.color === color && s.size === size
    );
    if (!stockItem) return 0;
    // Ensembles disponibles = min(vestes, pantalons)
    return Math.min(stockItem.jacketCount, stockItem.trouserCount);
  }
}

export const storage = new DatabaseStorage();
